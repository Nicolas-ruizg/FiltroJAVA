package Controladores;

import Modelos.Cuentas;

public class cuentaControlador  {


    public void crearCuenta(Cuentas cuenta) {
        System.out.println("Cuenta creada con saldo inicial de " + cuenta.getSaldo());
    }

    public void mostrarSaldo(Cuentas cuenta) {
        System.out.println("El saldo de la cuenta es: " + cuenta.getSaldo());
    }


}
