package Modelos;
import Controladores.usuarioControlador;
import java.util.Scanner;


public class MenuPrincipal {
    public void mostrarMenu() {
        Scanner scanner = new Scanner(System.in);
        usuarioControlador usuarioControlador = new usuarioControlador();

        System.out.println("1. Iniciar sesión");
        System.out.println("2. Registrar usuario");
        System.out.println("Seleccione una opción: ");
        int opcion = scanner.nextInt();

        if(opcion == 1) {
            /*System.out.println("Ingrese su correo: ");
            String correo = scanner.next();
            System.out.println("Ingrese su contraseña: ");
            String contrasena = scanner.next();
            boolean loginExitoso = usuarioControlador.login(correo, contrasena);

            if (loginExitoso) {
                System.out.println("Inicio de sesión exitoso.");
                // Continuar con el resto de la lógica
            } else {
                System.out.println("Correo o contraseña incorrectos.");
            }*/
        } else if(opcion == 2) {
            System.out.println("Ingrese identificacion: ");
            String identificacion = scanner.next();            
            System.out.println("Ingrese nombre: ");
            String nombre = scanner.next();
            System.out.println("Ingrese apellido: ");
            String apellido = scanner.next();
            System.out.println("Ingrese correo: ");
            String correo = scanner.next();
            System.out.println("Ingrese contraseña: ");
            String contrasena = scanner.next();
            System.out.println("Ingrese direccion: ");
            String direccion = scanner.next();
            System.out.println("Ingrese telefono: ");
            String telefono = scanner.next();
            
            

        } else {
            System.out.println("Opción no válida.");
        }
    }
  

    
}


