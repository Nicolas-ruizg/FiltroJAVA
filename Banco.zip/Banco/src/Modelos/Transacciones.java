/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

/**
 *
 * @author camper
 */
public class Transacciones {
    private int cuentaId;
    private double monto;
    private String tipo;  
    private String fecha;
    private String referencia;
    private double Saldo_anterior;
    private double Saldo_nuevo;
    private boolean estado;

    public Transacciones(int cuentaId, double monto, String tipo, String fecha, String referencia, double Saldo_anterior, double Saldo_nuevo, boolean estado) {
        this.cuentaId = cuentaId;
        this.monto = monto;
        this.tipo = tipo;
        this.fecha = fecha;
        this.referencia = referencia;
        this.Saldo_anterior = Saldo_anterior;
        this.Saldo_nuevo = Saldo_nuevo;
        this.estado = estado;
    }

    public int getCuentaId() {
        return cuentaId;
    }

    public void setCuentaId(int cuentaId) {
        this.cuentaId = cuentaId;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public double getSaldo_anterior() {
        return Saldo_anterior;
    }

    public void setSaldo_anterior(double Saldo_anterior) {
        this.Saldo_anterior = Saldo_anterior;
    }

    public double getSaldo_nuevo() {
        return Saldo_nuevo;
    }

    public void setSaldo_nuevo(double Saldo_nuevo) {
        this.Saldo_nuevo = Saldo_nuevo;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    

    
    
    
}
