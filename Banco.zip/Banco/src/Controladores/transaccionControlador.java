package Controladores;

import Modelos.Cuentas;

public class transaccionControlador {
    

    public void realizarDeposito(Cuentas cuenta, double monto) {
        cuenta.setSaldo(cuenta.getSaldo() + monto);
        System.out.println("Depósito realizado. Nuevo saldo: " + cuenta.getSaldo());
    }

    public void realizarRetiro(Cuentas cuenta, double monto) {
        if (cuenta.getSaldo() >= monto) {
            cuenta.setSaldo(cuenta.getSaldo() - monto);
            System.out.println("Retiro realizado. Nuevo saldo: " + cuenta.getSaldo());
        } else {
            System.out.println("Fondos insuficientes.");
        }
    }
}


