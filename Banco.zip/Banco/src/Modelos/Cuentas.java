package Modelos;

public class Cuentas {

        private int cuentaId;
        private double saldo;
        private String tipo;
        private boolean estado = true;

        public Cuentas(int id, int usuarioId, double saldo, String tipo) {
            this.cuentaId = usuarioId;
            this.saldo = saldo;
            this.tipo = tipo;
        }


    public int getUsuarioId() {
        return cuentaId;
    }

    public void setUsuarioId(int usuarioId) {
        this.cuentaId = usuarioId;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
