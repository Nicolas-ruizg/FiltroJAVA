package Bancoomevapp;

import ConexionDB.ConexionDB;
import Modelos.MenuPrincipal;

public class bancocoomevapp {
    public static void main(String[] args) {
        System.out.println("Bienvenido al Sistema de Gestión Financiera de Bancoomeva");
        ConexionDB conec = new ConexionDB();
        MenuPrincipal menu = new MenuPrincipal();
        menu.mostrarMenu();
        
    }
}
