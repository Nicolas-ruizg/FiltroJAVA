package ConexionDB;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexionDB {
    private static String url = "";
    public static Connection con = null;
    private static String user = "campus2023";
    private static String password = "campus2023";

    public static Connection ConexionBD1() {

        url = "jdbc:mysql://localhost:3306/banco_union";
        if (con == null) {
            try {

                con = DriverManager.getConnection(url, user, password);
                if (con != null) {
                    DatabaseMetaData meta = con.getMetaData();
                    System.out.println("Base de datos conectada " + meta.getDriverName());
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
        return con;
    }

    public static Connection getConexion() {
        synchronized (Connection.class) { 
            try {
                con = DriverManager.getConnection(url, user, password);
                Logger.getLogger(Connection.class.getName()).log(Level.INFO, "¡Conexión exitosa a la base de datos!");
            } catch (SQLException ex) {
                Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, "No se pudo establecer la conexión", ex);
            }
        }
        return con;
    }

    public static void cerrarConexion() {
        if (con != null) {
            try {
                con.close();
                Logger.getLogger(Connection.class.getName()).log(Level.INFO, "Conexión cerrada correctamente.");
            } catch (SQLException ex) {
                Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            } finally {
                con = null; 
            }
        }
    }
}