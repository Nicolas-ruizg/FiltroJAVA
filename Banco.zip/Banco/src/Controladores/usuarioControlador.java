package Controladores;

import ConexionDB.ConexionDB;
import ConexionDB.Crud;
import Modelos.Clientes;
import com.sun.jdi.connect.spi.Connection;
import java.util.Arrays;
import java.util.List;

public class usuarioControlador {
    public class UsuarioControlador {

    public boolean login() {
        System.out.println("hola"); 
        return false;
        
    }

    public boolean registrarUsuario(Clientes cliente) {
        Clientes cl = new Clientes();
        
        Crud.setConnection(ConexionDB.getConexion());
        
        String insercion = 
                "INSERT INTO habilidad (identificacion,nombre,apellido,direccion,telefono,correo,estado) "
                + "VALUES (?, ?, ?)";
    
        List<Object> parametros = Arrays.asList(
                cl.getIdentificacion(),
                cl.getNombre(),
                cl.getApellido());
        
        
        try{
            if(Crud.setAutoCommitBD(false)){
                if(Crud.insertarBD1(insercion, parametros)){
                    System.out.println("Registro exitoso!!");
                        Crud.commitBD();
                        return true;
                } else {
                    System.out.println("Error al registrar La habilidad");
                    Crud.rollbackBD();  
                }
            }
        }catch (Exception ex) {
            System.out.println("Error en la transacción: " + ex.getMessage());
            Crud.rollbackBD();
            throw ex;
        } finally {
            Crud.setAutoCommitBD(true);
            Crud.cerrarConexion(); 
        }
        
    }
    }
        


}
